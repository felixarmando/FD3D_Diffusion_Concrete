# include <cstdlib>
# include <iostream>
# include <iomanip>
# include <cmath>
#include <sstream> 
#include <string> 
#include <stdlib.h>
#include <stdio.h>


using namespace std;

# include "fd3d_diffusion.hpp"

int main ( );
void fd3d_diffusion_test ( );

void bc_test01 ( int x_num, double x[], double t, double *h );

void bc_test01_3D (  int x_num, int y_num, int z_num, double t, double *h  );

double *ic_test01_3D ( int x_num, int y_num, int z_num, double t );


double *rhs_test01 (  int num, double p[], double t );

double *set_porosity( int x_num, int y_num, int z_num, double min, double max );


string IntToString ( int number )
{
  std::ostringstream oss;

  // Works just like cout
  oss<< number;

  // Return the underlying string
  return oss.str();
  
  /*
  char result[50];
  sprintf(result, "%d", number);
  return result;
 char result[50];
  itoa(number, result, 2);
  return result;*/
}




//****************************************************************************80

int main ( )

//****************************************************************************80
//
//  Purpose:
//
//    MAIN is the main program for FD2D_DIFFUSION_PRB.
//
//  Discussion:
//
//    FD2D_DIFFUSION_TEST tests the FD2D_DIFFUSION library.
//
//  
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    Felix Mejia
//
{
  cout << "\n";
  cout << "FD3D_DIFFUSION_TEST:\n";
  cout << "  C++ version.\n";
  cout << "  Test the FD3D_DIFFUSION library.\n";

  fd3d_diffusion_test ( );
//
//  Terminate.
//
  cout << "\n";
  cout << "FD3D_DIFFUSION_TEST:\n";
  cout << "  Normal end of execution.\n";
  cout << "\n";
  timestamp ( );

  return 0;
}
//****************************************************************************80

void fd3d_diffusion_test ( )
//****************************************************************************80
//
//  Purpose:
//
//    FD2D_DIFFUSION_TEST.
////
//  
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    Felix Mejia
//


{
  double cflx;
  double cfly;
  double cflz;
  
  double dt;
  double *c;
  double *c_new;
  int i, h;
  int j;
  int vt;
  double k;
  double *t;
  double t_max;
  double t_min;
  int t_num;
  double *x;
  double x_max;
  double x_min;
  int x_num;


  double *y;
  double y_max;
  double y_min;
  int y_num;
  
  double *z;
  double z_max;
  double z_min;
  int z_num;
  
  double *porosity;
  
  
  
  cout << "\n";
  cout << "FD3D_DIFFUSION_TEST:\n";
  cout << "  Compute an approximate solution to the diffusion-dependent\n";
  cout << "  three dimensionals diffusion equation:\n";
  cout << "\n";
  cout << "    dU/dt - K * d2U/dx2 = f(x,t)\n";
  cout << "\n";
  cout << "  Run a simple test case.\n";
//
//  Diffusion coefficient.
//
  k = 1000.0;
//
//  X_NUM is the number of equally spaced nodes to use between Xmin and Xmax.
//
  x_num = 41;
  x_min = 0.0;
  x_max = 200.0;
  x = r8vec_linspace_new ( x_num, x_min, x_max );
  
  
//  Y_NUM is the number of equally spaced nodes to use between Ymin and Ymax.
//
  y_num = 41;
  y_min = 0.0;
  y_max = 200.0;
  y = r8vec_linspace_new ( y_num, y_min, y_max );
//

//  Z_NUM is the number of equally spaced nodes to use between Ymin and Ymax.
//
  z_num = 44;
  z_min = 10.0;
  z_max = 440.0;
  z = r8vec_linspace_new ( z_num, z_min, z_max );
//



//
//  T_NUM is the number of equally spaced time points between tmin and tmax.
//
  t_num = 15501;
  t_min = 0.0;
  t_max = 80.0;
  dt = ( t_max - t_min ) / ( double ) ( t_num - 1 );
  t = r8vec_linspace_new ( t_num, t_min, t_max );
//
//  Get the CFL coefficient.
//
  cflx = get_fd3d_diffusion_cfl ( k, t_num, t_min, t_max, x_num, x_min, x_max);
  cfly = get_fd3d_diffusion_cfl ( k, t_num, t_min, t_max, y_num, y_min, y_max);
  cflz = get_fd3d_diffusion_cfl ( k, t_num, t_min, t_max, z_num, z_min, z_max);
//
//  Running the code produces an array C of temperatures C(t,x)
//  
//
  c = ic_test01_3D ( x_num, y_num, z_num, t[0] );
  
  bc_test01_3D ( x_num, y_num, z_num, t[0], c );
  
  double minPorosity = 0.0;
  double maxPorosity = 0.99;
  porosity = set_porosity( x_num, y_num, z_num, minPorosity, maxPorosity);
  vt=0;
  string strNumber = IntToString(vt);
  string fileName = "Simulacion_" + strNumber + ".vtk";
  
  write_vtk3D ("Porosity.vtk", x_num,  x, y_num, y, z_num, z, porosity, "porosity" );
  write_vtk3D(fileName, x_num,  x, y_num, y, z_num, z, c, "chloride");
  for ( vt = 1; vt < t_num; vt++ )
  {
	cout << " time: " <<  vt <<"/" << t_num << "  \n";
	c_new = fd3d_diffusion ( x_num, x, y_num, y, z_num, z, t[vt-1], dt, cflx, cfly, cflz, porosity, rhs_test01, bc_test01_3D, c );

	for ( h = 0; h < z_num; h++ )
    	{
		for ( i = 0; i < x_num; i++ )
		{
			for ( j = 0; j < y_num; j++ )
			{
				c[i*y_num+j+h*(x_num*y_num)] = c_new[i*y_num+j+h*(x_num*y_num)];
			}
		}
	}
    strNumber = IntToString(vt);
    fileName = "Simulacion_" + strNumber + ".vtk";
    //
	//  Write the data to VTK files.
	//
    write_vtk3D(fileName, x_num,  x, y_num, y, z_num, z, c, "chloride");
    free(c_new);    
  }
  free (c);
  delete [] t;
  delete [] x;
  delete [] y;
  return;
}

//****************************************************************************80

void bc_test01_3D ( int x_num, int y_num, int z_num, double t, double *c )

//****************************************************************************80
//
//  Purpose:
//
//    BC_TEST01 evaluates the boundary conditions for problem 1.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license. 
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X[X_NUM], the node coordinates.
//
//    Input, double T, the current time.
//
//    Input, double H[X_NUM], the current heat values.
//
//    Output, double H[X_NUM], the current heat values, after boundary
//    conditions have been imposed.
//
{
	
	int i,j, k;
	
 
	for ( k = 0; k < z_num; k++ )
	{
		for ( i = 0; i < x_num; i++ )
		{
			c[i*y_num+k*(x_num*y_num)] = 0.06;
			c[i*y_num+y_num-1+k*(x_num*y_num)] = 0.06;
			//cout << "C[" <<  i << "," << x_num-1 << "," << k << "]= " << h[i*x_num+x_num-1+k*(x_num*y_num)] << "\n"  ;
			//cout << "C[" <<  i << "," << 0 << "," << k << "]= " << h[i*x_num+k*(x_num*y_num)] << "\n"  ;
		}
		for ( j = 1; j < y_num-1; j++ )
		{
			c[j+k*(x_num*y_num)] = 0.06;
			c[(x_num-1)*y_num+j+k*(x_num*y_num)] = 0.06;
			//cout << "C[" <<  0 << "," << j << "," << k << "]= " << h[j+k*(x_num*y_num)] << "\n"  ;
			//cout << "C[" <<  y_num-1 << "," << j << "," << k << "]= " << h[(y_num-1)*x_num+j+k*(x_num*y_num)] << "\n"  ;
		}
		
	}
  return;
}



//****************************************************************************80

double *ic_test01_3D ( int x_num, int y_num, int z_num, double t )

//****************************************************************************80
//
//  Purpose:
//
//    IC_TEST01 evaluates the initial condition for problem 1.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license. 
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X[X_NUM], the node coordinates.
//
//    Input, double T, the initial time.
//
//    Output, double H[X_NUM], the heat values at the initial time.
//
{
  int i,j, k;
  double *c;

  c = ( double * ) malloc ( x_num * y_num * (z_num) *sizeof ( double ) );
 
	for ( k = 0; k <z_num; k++ )
	{
		for ( i = 0; i < x_num; i++ )
		{
			for  ( j = 0; j < y_num; j++ )
			{
				c[i*y_num+j+k*(x_num*y_num)] = 0.0;
				//cout << "C[ " << i << "," << j << "," << k << "]= " << c[i*x_num+j+k*(x_num*y_num)] << "\n"  ;
				//getchar();
			}
		}
	}
  return c;
}

//****************************************************************************80

double *rhs_test01 ( int num, double p[], double t )

//****************************************************************************80
//
//  Purpose:
//
//    RHS_TEST01 evaluates the right hand side for problem 1.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license.
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X[X_NUM], the node coordinates.
//
//    Input, double T, the current time.
//
//    Output, double RHS_TEST01[X_NUM], the source term.
//
{
  int i;
  double *value;

  value = new double[num];

  for ( i = 0; i < num; i++ )
  {
    value[i] = 0.0;
  }
  return value;
}


//****************************************************************************80

 double *set_porosity( int x_num, int y_num, int z_num, double min, double max )
 
//****************************************************************************80
//
//  Purpose:
//
//    RHS_TEST01 evaluates the right hand side for problem 1.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license.
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X[X_NUM], the node coordinates.
//
//    Input, double T, the current time.
//
//    Output, double RHS_TEST01[X_NUM], the source term.
//
{
  int i,j, k;
  double *c;
  double r;
  double deltaM=(max - min)/RAND_MAX ;

	

  c = ( double * ) malloc ( x_num * y_num * (z_num) *sizeof ( double ) );
	long p=0;
	for ( k = 0; k < z_num; k++ )
	{
		for ( i = 0; i < x_num; i++ )
		{
			for  ( j = 0; j < y_num; j++ )
			{
				
				r = std::rand()*1.0/RAND_MAX  ;
				
				if(r<0.7)
				{
					c[i*y_num+j+k*(x_num*y_num)] = min + (r * deltaM*RAND_MAX);
					//cout << "r = " << c[i*y_num+j+k*(x_num*y_num)] << "\n" ;
				}
				else
				{
					//cout << "piedra " << p << "\n" ;
					p++;
					c[i*y_num+j+k*(x_num*y_num)] = 0.1;	
				}
				//c[i*x_num+j+k*(x_num*y_num)]=0.0;
				//cout << "Porosity[ " << i << "," << j << "," << k << "]= " << c[i*x_num+j+k*(x_num*y_num)] << "\n"  ;
			}
		}
	}
  return c;
}
