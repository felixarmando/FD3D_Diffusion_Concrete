# include <cstdlib>
#include <iostream>
#include <string>
# include <iomanip>
# include <fstream>
# include <ctime>
# include <cmath>


using namespace std;

# include "fd3d_diffusion.hpp"


double *fd3d_diffusion ( int x_num, double x[], int y_num, double y[], int z_num, double z[], double t, double dt, 
  double cflx, double cfly,  double cflz, double *porosity, double *rhs ( int y_num, double x[], double t ), 
  void bc ( int x_num, int y_num, int z_num, double t, double *h ), double *h )

//****************************************************************************80
//
//  Purpose:
//
//    FD2D_DIFFUSION: Finite difference solution of 2D Diffusion equation.
//
//  Discussion:
//
//    This program takes one time step to solve the 2D Diffusion equation 
//    with an explicit method.
//
//    This program solves
//
//      dUdT - k * d2UdX2 = F(X,T)
//
//    over the interval [A,B] with boundary conditions
//
//      U(A,T) = UA(T),
//      U(B,T) = UB(T),
//
//    over the time interval [T0,T1] with initial conditions
//
//      U(X,T0) = U0(X)
//
//    The code uses the finite difference method to approximate the
//    second derivative in space, and an explicit forward Euler approximation
//    to the first derivative in time.
//
//    The finite difference form can be written as
//
//      U(X,T+dt) - U(X,T)                  ( U(X-dx,T) - 2 U(X,T) + U(X+dx,T) )
//      ------------------  = F(X,T) + k *  ------------------------------------
//               dt                                   dx * dx
//
//    or, assuming we have solved for all values of U at time T, we have
//
//      U(X,T+dt) = U(X,T) 
//        + cfl * ( U(X-dx,T) - 2 U(X,T) + U(X+dx,T) ) + dt * F(X,T) 
//
//    Here "cfl" is the Courant-Friedrichs-Loewy coefficient:
//
//      cfl = k * dt / dx / dx
//
//    In order for accurate results to be computed by this explicit method,
//    the CFL coefficient must be less than 0.5.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license.
//
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of points to use in the 
//    spatial dimension.
//
//    Input, double X(X_NUM), the coordinates of the nodes.
//
//    Input, double T, the current time.
//
//    Input, double DT, the size of the time step.
//
//    Input, double CFL, the Courant-Friedrichs-Loewy coefficient,
//    computed by FD1D_HEAT_EXPLICIT_CFL.
//
//    Input, double H[X_NUM], the solution at the current time.
//
//    Input, double *RHS ( int x_num, double x[], double t ), the function 
//    which evaluates the right hand side.
//
//    Input, void BC ( int x_num, double x[], double t, double h[] ), 
//    the function which evaluates the boundary conditions.
//
//    Output, double FD1D_HEAT_EXPLICIT[X_NUM)], the solution at time T+DT.
//
{
	double *f;
	double *h_new;
	int j, i, k;

	f = rhs ( y_num, y, t );
	//cout <<  x_num << " - " << y_num << " - " << z_num << " \n";
	
	//h_new = ( double * ) malloc ( x_num * y_num * z_num * sizeof ( double ) );
	h_new = ( double * ) malloc ( x_num * y_num * (z_num) *sizeof ( double ) );

	
	//cout << " New MAtriz \n";
	k=0;
	for(i = 1; i < x_num - 1; i++ )
		{
		  for ( j = 1; j < y_num - 1; j++ )
		  {
			h_new[i*y_num+j+k*(x_num*y_num)] = h[i*y_num+j] + dt * f[j] 
			  + (cfly*porosity[i*y_num+j+k*(x_num*y_num)]) * (         h[i*y_num+j-1]
						- 2.0 * h[i*y_num+j]
						+       h[i*y_num+j+1] ) + (cflx*porosity[i*y_num+j+k*(x_num*y_num)]) * ( h[(i-1)*y_num+j]
						- 2.0 * h[i*y_num+j]
						+       h[(i+1)*y_num+j] )+ (cflz*porosity[i*y_num+j+k*(x_num*y_num)]) * (1.0*h[i*y_num+j+(k+2)*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+(k)*(x_num*y_num)]
						+       h[i*y_num+j+(k+1)*(x_num*y_num)] );
		  }
		}
	
	
		//cout << " K0 \n";
	for(k = 1; k < z_num -1; k++ )
	{
		
		for(i = 1; i < x_num - 1; i++ )
		{
		  for ( j = 1; j < y_num - 1; j++ )
		  {
			h_new[i*y_num+j+k*(x_num*y_num)] = h[i*y_num+j+k*(x_num*y_num)] + dt * f[j] 
			  + (cfly*porosity[i*y_num+j+k*(x_num*y_num)]) * (         h[i*y_num+j-1+k*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+k*(x_num*y_num)]
						+       h[i*y_num+j+1+k*(x_num*y_num)] ) + (cflx*porosity[i*y_num+j+k*(x_num*y_num)]) * (h[(i-1)*y_num+j+k*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+k*(x_num*y_num)]
						+       h[(i+1)*y_num+j+k*(x_num*y_num)] ) + (cflz*porosity[i*y_num+j+k*(x_num*y_num)]) * (h[i*y_num+j+(k-1)*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+k*(x_num*y_num)]
						+       h[i*y_num+j+(k+1)*(x_num*y_num)] );
			//cout << i*x_num+j+(k+1)*(x_num*y_num) << " \n";
			//cout << "C[" <<  i << "," << j << "," << k << "]= " << h[i*x_num+j+(k+1)*(x_num*y_num)]<< "__"  ;
		  }
		}
		//cout << " K = " << k << " \n";
	}
	
	k=z_num-1;
	//cout << " \n K = " << k << " \n";
	for(i = 1; i < x_num - 1; i++ )
		{
		  for ( j = 1; j < y_num - 1; j++ )
		  {
			h_new[i*y_num+j+k*(x_num*y_num)] = h[i*y_num+j+k*(x_num*y_num)] +
			  + (cfly*porosity[i*y_num+j+k*(x_num*y_num)]) * ( h[i*y_num+j-1+k*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+k*(x_num*y_num)]+  h[i*y_num+j+1+k*(x_num*y_num)] ) 
			  + (cflx*porosity[i*y_num+j+k*(x_num*y_num)]) * ( h[(i-1)*y_num+j+k*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+k*(x_num*y_num)]+  h[(i+1)*y_num+j+k*(x_num*y_num)] ) 
			  + (cflz*porosity[i*y_num+j+k*(x_num*y_num)]) * ( h[i*y_num+(k-1)*(x_num*y_num)]
						- 2.0 * h[i*y_num+j+(k)*(x_num*y_num)]	+   1.0*  h[i*y_num+j+(k-2)*(x_num*y_num)] );
		  }
		}
			
	bc ( x_num, y_num, z_num, t + dt, h_new );

  delete [] f;
  return h_new;
}



//****************************************************************************80

double *ic_3D ( int x_num, int y_num, int z_num )

//****************************************************************************80
//
//  Purpose:
//
//    IC_TEST01 evaluates the initial condition for problem 1.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license. 
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X[X_NUM], the node coordinates.
//
//    Input, double T, the initial time.
//
//    Output, double H[X_NUM], the heat values at the initial time.
//
{
  int i,j, k;
  double *c;

  c = ( double * ) malloc ( x_num * y_num * (z_num) *sizeof ( double ) );
 
	for ( k = 0; k <z_num; k++ )
	{
		for ( i = 0; i < x_num; i++ )
		{
			for  ( j = 0; j < y_num; j++ )
			{
				c[i*y_num+j+k*(x_num*y_num)] = 0.0;
				//cout << "C[ " << i << "," << j << "," << k << "]= " << c[i*x_num+j+k*(x_num*y_num)] << "\n"  ;
				//getchar();
			}
		}
	}
  return c;
}



//****************************************************************************80

double fd3d_diffusion_cfl ( double k, int t_num, double t_min, double t_max, 
  int x_num, double x_min, double x_max, int y_num, double y_min, double y_max, int z_num, double z_min, double z_max )

//****************************************************************************80
//
//  Purpose:
//
//    FD2D_DIFFUSION_CFL: compute the Courant-Friedrichs-Loewy coefficient.
//
//  Discussion:
//
//    The equation to be solved has the form:
//
//      dUdT - k * d2UdX2 = F(X,T)
//
//    over the interval [X_MIN,X_MAX][Y_MIN,Y_MAX] with boundary conditions
//
//      U(X_MIN,T) = U_X_MIN(T),
//      U(X_MIN,T) = U_X_MAX(T),
//
//    over the time interval [T_MIN,T_MAX] with initial conditions
//
//      U(X,T_MIN) = U_T_MIN(X)
//
//    The code uses the finite difference method to approximate the
//    second derivative in space, and an explicit forward Euler approximation
//    to the first derivative in time.
//
//    The finite difference form can be written as
//
//      U(X,T+dt) - U(X,T)                  ( U(X-dx,T) - 2 U(X,T) + U(X+dx,T) )
//      ------------------  = F(X,T) + k *  ------------------------------------
//               dt                                   dx * dx
//
//    or, assuming we have solved for all values of U at time T, we have
//
//      U(X,T+dt) = U(X,T) 
//        + cfl * ( U(X-dx,T) - 2 U(X,T) + U(X+dx,T) ) + dt * F(X,T) 
//
//    Here "cfl" is the Courant-Friedrichs-Loewy coefficient:
//
//      cfl = k * dt / dx / dx
//
//    In order for accurate results to be computed by this explicit method,
//    the CFL coefficient must be less than 0.5!
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license. 
//
//  Modified:
//
//    26 January 2012
//
//  Author:
//
//    John Burkardt
//
//  Reference:
//
//    George Lindfield, John Penny,
//    Numerical Methods Using MATLAB,
//    Second Edition,
//    Prentice Hall, 1999,
//    ISBN: 0-13-012641-1,
//    LC: QA297.P45.
//
//  Parameters:
//
//    Input, double K, the heat conductivity coefficient.
//
//    Input, int T_NUM, the number of time values, including 
//    the initial value.
//
//    Input, double T_MIN, T_MAX, the minimum and maximum times.
//
//    Input, int X_NUM, the number of nodes.
//
//    Input, double X_MIN, X_MAX, the minimum and maximum spatial 
//    coordinates.
//
//    Output, double FD1D_HEAT_EXPLICIT_CFL, the Courant-Friedrichs-Loewy coefficient.
//
{
  double cfl;
  double dx, dy, dz;
  double dt;

  dx = ( x_max - x_min ) / ( double ) ( x_num - 1 );
  dy = ( y_max - y_min ) / ( double ) ( y_num - 1 );
  dz = ( z_max - z_min ) / ( double ) ( z_num - 1 );
  dt = ( t_max - t_min ) / ( double ) ( t_num - 1 );
//
//  Check the CFL condition, print out its value, and quit if it is too large.
//
  cfl = k * dt / dx / dx + k * dt / dy / dy + k * dt / dz / dz;

  cout << "\n";
  cout << " CFL stability criterion value = " << cfl << "\n";

  if ( 0.5 <= cfl )
  {
    cerr << "\n";
    cerr << "FD3D_DIFFUSION_CFL - Fatal error!\n";
    cerr << "  CFL condition failed.\n";
    cerr << "  0.5 <= K * dT / dX / dX + K * dT / dY / dY  = CFL.\n";
    exit ( 1 );
  }

  return cfl;
}

double get_fd3d_diffusion_cfl ( double k, int t_num, double t_min, double t_max, 
  int x_num, double x_min, double x_max)
{
  double cfl;
  double dx, dy, dz;
  double dt;

  dx = ( x_max - x_min ) / ( double ) ( x_num - 1 );
  dt = ( t_max - t_min ) / ( double ) ( t_num - 1 );
//
//  Check the CFL condition, print out its value, and quit if it is too large.
//
  cfl =  k*dt / (dx * dx);

  cout << "\n";
  cout << " CFL stability criterion value = " << cfl << "\n";

  if ( 0.5 <= cfl )
  {
    cerr << "\n";
    cerr << "FD3D_DIFFUSION_CFL - Fatal error!\n";
    cerr << "  CFL condition failed.\n";
    cerr << "  0.5 <= K * dT / dX / dX + K * dT / dY / dY  = CFL.\n";
    exit ( 1 );
  }

  return cfl;
}


//****************************************************************************80

double *r8vec_linspace_new ( int n, double a_first, double a_last )

//****************************************************************************80
//
//  Purpose:
//
//    R8VEC_LINSPACE_NEW creates a vector of linearly spaced values.
//
//  Discussion:
//
//    An R8VEC is a vector of R8's.
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license.
//
//  Modified:
//
//    29 March 2011
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    Input, int N, the number of entries in the vector.
//
//    Input, double A_FIRST, A_LAST, the first and last entries.
//
//    Output, double R8VEC_LINSPACE_NEW[N], a vector of linearly spaced data.
//
{
  double *a;
  int i;

  a = ( double * ) malloc ( n * sizeof ( double ) );

  if ( n == 1 )
  {
    a[0] = ( a_first + a_last ) / 2.0;
  }
  else
  {
    for ( i = 0; i < n; i++ )
    {
      a[i] = ( ( double ) ( n - 1 - i ) * a_first 
             + ( double ) (         i ) * a_last ) 
             / ( double ) ( n - 1     );
    }
  }
  return a;
}

//****************************************************************************80

void timestamp ( )

//****************************************************************************80
//
//  Purpose:
//
//    TIMESTAMP prints the current YMDHMS date as a time stamp.
//
//  Example:
//
//    31 May 2001 09:45:54 AM
//
//  Licensing:
//
//    This code is distributed under the GNU LGPL license. 
//
//  Modified:
//
//    08 July 2009
//
//  Author:
//
//    John Burkardt
//
//  Parameters:
//
//    None
//
{
# define TIME_SIZE 40

  static char time_buffer[TIME_SIZE];
  const struct std::tm *tm_ptr;
  std::time_t now;

  now = std::time ( NULL );
  tm_ptr = std::localtime ( &now );

  std::strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm_ptr );

  std::cout << time_buffer << "\n";

  return;
# undef TIME_SIZE
}


//****************************************************************************80

double *coefficient_diffusion_co2( double *p , double h, int n, int m)

//****************************************************************************80
//
//  Purpose:
//
//    coefficient_diffusion_co2 calculate the coefficient diffusion of carbon dioxide.
//
//
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    Félix Armando Mejía Cajicá
//
//  Parameters:
//
//    Input, double p, the porosity of hardered binder.
//
//    Input, double h, the humidity.
//
//    Output, double coefficient_diffusion_co2, Coefficient Diffusion.
//
{
	int i,j;
	double *Dco2;
	Dco2 = ( double * ) malloc ( n * m * sizeof ( double ) );
	
	for(i = 0; i < n ; i++ )
	{
	  for ( j = 0; j < m ; j++ )
	  {
		  Dco2[i*m+j] = 1.64 * pow(10.0, -6.0)*pow(p[i*m+j], 1.8)*pow(1.0-h, 2.2); 
		  
	  }
	}
	return Dco2;
}


//****************************************************************************80

double *porosity_co2( double *por_ini , double *por_current, double *por_last, double *co2, int n, int m)

//****************************************************************************80
//
//  Purpose:
//
//    POROSITY calculate the current porosity of concrete.
//
//
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    Félix Armando Mejía Cajicá
//
//  Parameters:
//
//    Input, double *por_ini, the porosity initial.
//
//    Input, double h, the humidity.
//
//    Output, double coefficient_diffusion_co2, Coefficient Diffusion.
//
{
	double *por;
	int i,j;
	
	por = ( double * ) malloc ( n * m * sizeof ( double ) );
	
	for(i = 0; i < n ; i++ )
	{
	  for ( j = 0; j < m ; j++ )
	  {
		por[i*m+j] = por_ini[i*m+j] - (por_current[i*m+j]-por_last[i*m+j])*co2[i*m+j];  
	  }
	}
	return por;
}


//********************************************************************************************

void write_vtk3D ( string output_filename, int n, double x[], int m, double y[], int h, double z[], double *c, string variable )

//*******************************************************************************************
//
//  Purpose:
//
//    WRITE_VTK writes an VTK Unstructured file.
//
//  Modified:
//
//    26 October 2017
//
//  Author:
//
//    Félix Armando Mejía
//
//  Parameters:
//
//    Input, string OUTPUT_FILENAME, the output filename.
//
//    Input, int N, the number of points in X.
//
//    Input, double X[N], pointS in X.
//
//    Input, int M, the number of points in Y.
//
//    Input, double Y[M], pointS in Y.
//    
//    Input, double *c, Matrix of Chloride Concentration .
//
{
  int j, i, k;
  ofstream output;
//
//  Open the file.
//
  output.open ( output_filename.c_str ( ) );

  if ( !output )
  {
    cerr << "\n";
    cerr << "WRITE_VTK - Fatal error!\n";
    cerr << "  Could not open the output file.\n";
    exit ( 1 );
  }
//
//  Write the data.
//

	output << "# vtk DataFile Version 2.0\n";
	output << "Simula \n";
	output << "ASCII\n";
	output << "DATASET UNSTRUCTURED_GRID\n";
	output << "POINTS "<< n*m*h << " double\n" ;
	

  for ( k = 0; k < h; k++ )
  {
	  for ( i = 0; i < n; i++ )
	  {
		  for ( j = 0; j < m; j++ )
		  {
			output << x[i] <<  " " << y[j] <<  " " << z[k]  <<" \n";
		  }
	  }
  }
  output << "CELLS "<< (n-1)*(m-1)*(h-1) << "   " << (n-1)*(m-1)*(h-1)*9  << " \n";
  int numPoints = 8; 
  for ( k = 0; k < h-1; k++ )
  {
	  for ( i = 0; i < n-1; i++ )
	  {
		  for ( j = 0; j < m -1 ; j++ )
		  {
			//output <<  numPoints <<  " " << i*m+j+k*(n*m) <<  " " << i*m+j+1+k*(n*m) << " " << (i+1)*m+j+k*(n*m) << " " << (i+1)*m+j+1+k*(n*m);
			//output <<  " " << i*m+j+(k+1)*(n*m) <<  " " << i*m+j+1+(k+1)*(n*m) << " " << (i+1)*m+j+(k+1)*(n*m) << " " << (i+1)*m+j+1+(k+1)*(n*m) << "\n";

			output <<  numPoints <<  " " << i*m+j+k*(n*m) <<  " " << (i+1)*m+j+k*(n*m)  << " " <<  (i+1)*m+j+1+k*(n*m) << " " << i*m+j+1+k*(n*m);
			output <<  " " << i*m+j+(k+1)*(n*m) <<  " " <<  (i+1)*m+j+(k+1)*(n*m)  << " " << (i+1)*m+j+1+(k+1)*(n*m) << " " << i*m+j+1+(k+1)*(n*m) << "\n";
		  }
	  }
  }
  
  output << "CELL_TYPES "<< (n-1)*(m-1)*(h-1) << " \n";
  int cellType = 12; 
  for ( i = 0; i < (n-1)*(m-1)*(h-1); i++ )
  {
	  output <<  cellType << " \n";
  }
  output << "POINT_DATA "<< n*m*h << "\n" ;
  output << "SCALARS " << variable << " double" << " \n";
  output << "LOOKUP_TABLE default\n";
  for ( k = 0; k < h; k++ )
  {
	  for ( i = 0; i < n; i++ )
	  {
		  for ( j = 0; j < m; j++ )
		  {
			output << c[i*m+j+k*(n*m)] << "\n";
		  }
	  }
  }
//
//  Close the file.
//
  output.close ( );

  return;
}


