  
double *fd3d_diffusion ( int x_num, double x[], int y_num, double y[],  int z_num, double z[], double t, double dt, 
  double cflx, double cfly, double cflz, double *porosity , double *rhs ( int x_num, double x[], double t ), 
  void bc ( int x_num, int y_num, int z_num, double t, double *h ), double *h );
  
double fd3d_diffusion_cfl ( double k, int t_num, double t_min, double t_max, 
  int x_num, double x_min, double x_max, int y_num, double y_min, double y_max, int z_num, double z_min, double z_max );
 
 
double get_fd3d_diffusion_cfl ( double k, int t_num, double t_min, double t_max, 
  int x_num, double x_min, double x_max );
  
  
double *r8vec_linspace_new ( int n, double a_first, double a_last );

void timestamp ( );

double *coefficient_diffusion_co2(double *p , double h, int n, int m);
double *porosity_co2(double *por_ini , double *por_current, double *por_last, double *co2, int m, int n);

double *ic_3D ( int x_num, int y_num, int z_num );

void write_vtk3D ( string output_filename, int n, double x[], int m, double y[], int h, double z[], double *c, string variable  );

